#!/bin/bash
rm -rf 2ala.pdb COLVAR COLVAR.bak COLVAR.old  com.trr confout.gro current.gro  ener.edr frames.ndx indexes_ md.log mdout.mdp  outcomm points state* topol.tpr traj.trr trajout.xtc indexes_* traj.dcd plumed2.dat plumedcom.dat \#* 
